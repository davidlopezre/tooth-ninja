//
//  ViewController.swift
//  CGAffine_test
//
//  Created by ritu sharma on 26/5/18.
//  Copyright © 2018 Kush. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var transMiller = CGAffineTransform()
    var counter = 0
    let box = UIView(frame: CGRect(x: 0, y: 0, width: 324, height: 32))
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        box.backgroundColor = .red
        view.addSubview(box)
        box.setAnchorPoint(CGPoint(x:0,y:0))
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func box(_ sender: Any)
    {
        counter += 1
        if(counter < 4)
        {
            transMiller = CGAffineTransform(scaleX: -0.1, y: 1)
            box.transform = transMiller
        }
        
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

